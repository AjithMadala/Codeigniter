<?php
class Auth extends CI_Controller{
    
    public function login(){

        $this->load->view('login');
    }
    public function register(){
        if(isset($_POST['register'])){
            $this->form_validation->set_rules('username','Username','required');
            $this->form_validation->set_rules('email','Email','required');
            $this->form_validation->set_rules('password','Password','required');
            $this->form_validation->set_rules('password','Confirm Password','required|min_length[8]|matches[password]');
            $this->form_validation->set_rules('mobile','Mobile','required|min_length[10]');


            //check for form validation
            if($this->form_validation->run()==TRUE){
                echo "Registration Successfull";

                //add user
                $data=array(
                    'username'=>$_POST['username'],
                    'email'=>$_POST['email'],
                    'mobile'=>$_POST['mobile'],
                    'password'=>$_POST['password']

                );
                $this->db->insert('users',$data);
                $this->session->set_flashdata("Success","Your Account is Registered");
                redirect("Auth/login","refresh");
            }
        }
        $this->load->view('register');
    }
}
?>