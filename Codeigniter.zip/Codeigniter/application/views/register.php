<!DOCTYPE html>
<html>
<head>
<title></title>
<link href="<?php echo base_url(); ?>BootstrapCdn/css/bootstrap.min.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>

</head>
<body>

<div class="d-flex justify-content-center">
      <?php if(isset($_SESSION['success'])) {?>
         <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
         <?php 
      } ?>
<?php echo validation_errors('<div class="alert alert-danger">','</div>');?>
<form action="" method="POST">      
<div class="row">
            <div class="col-md-4">
               <label for="us">Username</label>
               <input type="text" name="usr" class="form-control" id="us" required>
            </div>
         </div>

         <div class="row">
            <div class="col-md-4">
               <label for="email">Email</label>
               <input type="email" name="email" class="form-control" id="email" required>
            </div>
         </div>

         <br>

         <div class="row">
            <div class="col-md-4">
               <label for="mobile">Mobile</label>
               <input type="number" name="mobile" class="form-control" id="mobile" required>
            </div>
         </div>
         
         <div class="row">
            <div class="col-md-4">
               <label for="passw">Password</label>
               <input type="password" name="passw" class="form-control" id="passw" required>
            </div>
         </div>
         
         <div class="row">
            <div class="col-md-4">
               <label for="cnfp">Confirm Password</label>
               <input type="password" name="cnfpassw" class="form-control " id="cnfpassw" required>
            </div>
         </div>
         <br><br>
         <div class="row ">
            <div class="col-md-4">
            <button class="btn btn-primary">Register</button>            
            </div>
         </div>
</div>
      </form>
      
<script src="<?php echo base_url(); ?>BootstrapCdn/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>BootstrapCdn/js/bootstrap.min.js"></script>
</body>
</html>