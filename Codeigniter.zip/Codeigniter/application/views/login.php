<!DOCTYPE html>
<html>
<head>
<title></title>
<link href="<?php echo base_url(); ?>BootstrapCdn/css/bootstrap.min.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin-top:250px;
}
</style>

</head>
<body>
<div class="col-md-3 col-md-offset-4">
      <form action="login.php" method="POST">

        <div class="form-group">
               <label for="us">Username</label>
               <input type="text" name="usr" class="form-control" id="us" required>
        </div>

         <br>
         <div class="form-group">
               <label for="p">Password</label>
               <input type="password" name="passw" class="form-control" id="p" required>
        </div>
     <br><br>
         <div class="form-group">
               <input type="submit" class="form-control">
        </div>
</div>

</body>      
<script src="<?php echo base_url(); ?>BootstrapCdn/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>BootstrapCdn/js/bootstrap.min.js"></script>
</body>
</html>